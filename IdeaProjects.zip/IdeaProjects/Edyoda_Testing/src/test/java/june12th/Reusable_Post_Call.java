package june12th;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import requestbody.Request_Body;
import reusable.Reusable_Fun;


import static io.restassured.RestAssured.given;

public class Reusable_Post_Call extends Reusable_Fun {

    public Request_Body req_object;

    @BeforeClass
    public void setup() {
        req_object=new Request_Body();
    }
    @Test
    public void Create_User()
    {
//RestAssured.baseURI = "https://petstore.swagger.io/v2/pet";
        Response res =Get_Res_Post_call("https://reqres.in/api/users",
                req_object.Create_User_ID_Req_body("Sandeep","TestEng"));
        //logger.info("Get Pet API call's for : https://petstore.swagger.io/v2/pet");
        int user_status_code = res.getStatusCode();
        Assert.assertEquals(user_status_code, 201);
        //logger.pass("The Pet status code is as expected  as --> " + Pet_status_code);
        //System.out.println("the JSON code ===>" + res.asString());
        System.out.println("the status code ===>" + user_status_code);
        String user_job_res=res.getBody().jsonPath().getString("job");
        String user_name_res=res.getBody().jsonPath().getString("name");
        System.out.println("the JSON user name===>"+user_job_res);
        System.out.println("the JSON user job===>"+user_name_res);
        //logger.info("the JSON pet Id : " +pet_id_res);
        //logger.info("the JSON pet name : " +pet_name_res);
    }

    @Test
    public void create_Pet_ID()
    {
        //RestAssured.baseURI = "https://petstore.swagger.io/v2/pet";
        Response res =Get_Pet_Res_Post_call("https://reqres.in/api/users",
                req_object.creatPait_Req_Body("222","COW"));

        //logger.info("Get Pet API call's for : https://petstore.swagger.io/v2/pet");
        int Pet_status_code = res.getStatusCode();
        Assert.assertEquals(Pet_status_code, 201);
        //logger.pass("The Pet status code is as expected  as --> " + Pet_status_code);
        System.out.println("the JSON code ===>" + res.asString());
        System.out.println("the status code ===>" + Pet_status_code);
        String pet_id_res=res.getBody().jsonPath().getString("id");
        String pet_name_res=res.getBody().jsonPath().getString("name");
        System.out.println("the JSON pet id===>"+pet_id_res);
        System.out.println("the JSON pet name===>"+pet_name_res);
        //logger.info("the JSON pet Id : " +pet_id_res);
        //logger.info("the JSON pet name : " +pet_name_res);
    }

}
