package javaAssignment;

public class Student {
    private String name;

    public String getName()
    {
        return getName();
    }
    public void setName(String name)
    {
        this.name=name;
    }

}
