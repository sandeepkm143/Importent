package coreJava;

import java.sql.SQLOutput;

public class Test_Method_Overload {

    public static void Method1()
    {
        System.out.println("Print method1");
    }
    public static void Method1(int x,int y)
    {
        System.out.println("Print method1 Integer arguments "+x+"==>"+y);
    }
    public static void Method1(String x,String y)
    {
        System.out.println("Print method1 String arguments "+x+"==>"+y);
    }
    public static void Method1(String x,int y)
    {
        System.out.println("Print method1 String & Integer arguments "+x+"==>"+y);
    }
    public static void Method1(int x,int y,int z)
    {
        System.out.println(x+y+z);
    }

    public static void main(String[] args)
    {
        Test_Method_Overload.Method1();
        Test_Method_Overload.Method1(10,20);
        Test_Method_Overload.Method1("Hello","Hi");
        Test_Method_Overload.Method1("Hello",20);
        Test_Method_Overload.Method1(10,20,30);


    }

}
