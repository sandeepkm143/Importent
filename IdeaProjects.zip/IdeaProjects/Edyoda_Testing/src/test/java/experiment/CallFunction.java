package experiment;

import org.testng.annotations.Test;

public class CallFunction {

    ReadExcel obj_redexcel;

    @Test
    public void Read_URL()
    {
        obj_redexcel=new ReadExcel();
        obj_redexcel.read_Test_Data_From_Excel_aspertestcasess("TC_001","URL","Title");
        obj_redexcel.read_Test_Data_From_Excel_aspertestcasess("TC_002","URL","Title");
        obj_redexcel.read_Test_Data_From_Excel_aspertestcasess("TC_003","URL","Title");
        obj_redexcel.read_Test_Data_From_Excel_aspertestcasess("TC_004","URL","Title");
        obj_redexcel.read_Test_Data_From_Excel_aspertestcasess("TC_005","URL","Title");
    }

}
