package may19;

import org.testng.annotations.*;

public class Test_001 {

    @BeforeTest
    public void dosetupforTC001()
    {
        System.out.println("Start API server for Tc001");
    }
    @Test(priority = 1)
    public void testing_Google_Page()
    {
        System.out.println("I am executing my first script");
    }
    //@Test(priority = 2)
    @Parameters({"Num"})
    public void testing_Facebook_Page(String Num)
    {
        System.out.println(100+100+Integer.valueOf(Num));
    }

    @AfterTest
    public void closesetupforTC001()
    {
        System.out.println("stop API server for Tc001");
    }















}
