package control_Loop;



public class Java_Constructor_Intrerface {

    class Student{

        int id;
        String name;
        public void  main(String args[])
        {
            Student s1=new Student();
            System.out.println(s1.name);
            System.out.println(s1.name);


        }

    }





}
