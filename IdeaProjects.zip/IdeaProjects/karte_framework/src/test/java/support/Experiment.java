package support;
import org.junit.jupiter.api.Test;
public class Experiment {

    @Test
    public void read_data()
    {
        Reusable obj=new Reusable();
        System.out.println(obj.read_Excel1("TC_002","pet_id"));
        System.out.println(obj.read_Excel1("TC_002","pet_name"));
    }
}
