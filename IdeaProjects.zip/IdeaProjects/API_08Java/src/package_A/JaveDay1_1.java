package package_A;

public class JaveDay1_1 {
}
