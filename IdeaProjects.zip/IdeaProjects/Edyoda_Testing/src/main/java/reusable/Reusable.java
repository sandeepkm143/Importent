package reusable;

import java.util.*;
import java.io.*;

import com.google.common.annotations.VisibleForTesting;

public class Reusable {

    public String read_Properties_File(String key)
    {
        String value=null;
        try
        {
            FileReader read=new FileReader(System.getProperty("user.dir")+"\\testData.properties");
            Properties prop=new Properties();
            prop.load(read);
            value=prop.getProperty(key);


        }

        catch (Exception e)
        {

        }
        return value;

    }






}
