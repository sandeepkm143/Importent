package may15;

public class Lerning_arry {
    String studentname[];
    String student_roll;
    String studentset = "1:Ravi,2:Ram,3:Vikas,4:Sam,5:Tina";
    int i=0;
    int a=0;
    public static void  main(String args[])
    {
        Lerning_arry obj=new Lerning_arry();
        //obj.lerning_an_array(20);
        //obj.get_the_student_name_with_Index();
        obj.get_the_student_name_with_Rollnumber();
    }
    public void lerning_an_array(int student_index)
    {
        studentname = new String[100];
        for(i=0;i<100;i++)
        {
            studentname[i]="student"+" "+i;
        }
        System.out.println("The student name of the index"+student_index+"===>"+studentname[student_index]);
    }

    public void get_the_student_name_with_Index(){
        String [] studentsetbyIndex=studentset.split(",");

        for (a=0;a<studentsetbyIndex.length;a++)
        {
            System.out.println(studentsetbyIndex[a]);
        }

   }

   public void get_the_student_name_with_Rollnumber(){
        String[] student_Comma=studentset.split(",");

        for(a=0;a<student_Comma.length;a++)
        {
            //System.out.println(student_Comma[1]);
            String[] student_roll=student_Comma[a].split(":");
            System.out.println("if the student name is "+student_roll[1]+" "+"Then His/her roal number is==>"+student_roll[0]);
        }

   }

}
