package coreJava;

public class Bike1 {
    // default constructor
    Bike1()
    {
        System.out.println("Bike is created");
    }
    public static void main(String args[]){
        Bike1 b = new Bike1();
    }

    }
