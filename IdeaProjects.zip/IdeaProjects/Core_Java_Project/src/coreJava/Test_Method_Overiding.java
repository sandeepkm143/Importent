package coreJava;

public class Test_Method_Overiding {
    int x;
    int y;

    public static void add(int x, int y) {
        int z = x + y;
        System.out.println(z);
    }


    public class Test_Method_Overiding1 extends Test_Method_Overiding {
        int x;
        int y;

        public static void add(int x, int y) {
            int z = x - y;
            System.out.println(z);
        }
    }

    public static void main(String[] args)
    {
        Test_Method_Overiding1.add(30,20);
    }
}




