package javaAssignment;

public class Test {
    public void main(String[] args)
    {
        Student s=new Student();
        s.setName("John");
        System.out.printf(s.getName());

    }
}
