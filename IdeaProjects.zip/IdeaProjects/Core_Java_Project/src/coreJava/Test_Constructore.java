package coreJava;

public class Test_Constructore {
char x;
char y;
    public Test_Constructore()
    {
//x=10;
//y=20;
    }

    public static void main(String[] args)
    {
        Test_Constructore obj=new Test_Constructore();
        System.out.println(obj.x);
        System.out.println(obj.y);
    }
}
