package may15;

public class Learn_Java_Constructor {
    int x;
    int y;
    public Learn_Java_Constructor()
    {
        x=10;
        y=20;
    }

    public static void main(String[] args)
    {
        Learn_Java_Constructor obj=new Learn_Java_Constructor();
        System.out.println(obj.x);
        System.out.println(obj.y);
    }
}
