package control_Loop;

public class JavaControlrateofintrest {

    public static void main(String[] args)throws Exception{

        JavaControlrateofintrest obj=new JavaControlrateofintrest();
        System.out.println(obj.rate_of_home_intrest("sbi"));
        obj.eligible_for_trip(200);

    }

    public int rate_of_home_intrest(String bankname)
    {
        int rateofintrest=0;

        if(bankname.equals("sbi"))
        {
            rateofintrest=9;
        }
        if(bankname.equals("pnb"))
        {
            rateofintrest=10;
        }
        if(bankname.equals("icici"))
        {
            rateofintrest=11;
        }
        if(bankname.equals("hdfc"))
        {
            rateofintrest=12;
        }
        return rateofintrest;
    }

    public void eligible_for_trip(int age) {
        if (age <= 18 || age > 60) {
            System.out.println("you are not eligible for the trip as your age is" + age);
        }

        else if (age > 18 || age <= 60) {
            System.out.println("you are eligible for the trip as your age is" + age);
        }
        else
        {
            System.out.println("you are not giving incorrect age as" + age);
        }
    }

}
