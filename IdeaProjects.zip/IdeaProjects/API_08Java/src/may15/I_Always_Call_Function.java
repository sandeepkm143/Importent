package may15;

public class I_Always_Call_Function extends Lern_Switch_Statiement {

    public static void main(String args[]){

        I_Always_Call_Function obj=new I_Always_Call_Function();
        obj.print_the_day(7);
    }

}
