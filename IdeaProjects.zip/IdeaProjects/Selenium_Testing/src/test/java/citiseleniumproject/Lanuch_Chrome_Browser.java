package citiseleniumproject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.List;

public class Lanuch_Chrome_Browser {

    public WebDriver driver;
    int i=0;
@Test
    public void lanuch_Chrome()
{
    //System.setProperty("webdriver.chrome.driver","C:\\Users\\sandeepkm\\Desktop\\Selenium\\chromedriver.exe");
    driver=new FirefoxDriver();
    driver.get("https://google.com");
    //System.out.println(driver.getTitle());
    //System.out.println(driver.getCurrentUrl());

    //System.out.println(driver.getPageSource());
    //driver.findElement(By.id("APjFqb")).sendKeys("abc");
    List<WebElement> ele= driver.findElements(By.tagName("a"));
    System.out.println(ele.size());
    String[] linkTexts = new String[ele.size()];
    for(WebElement e:ele)
    {
        System.out.println(linkTexts[i]=e.getText());
        i++;
    }
    //driver.close();
    //Select frutes=new Select(driver.findElement(By.id("abc")));
    //frutes.selectByIndex(0);
    ////frutes.se

driver.quit();
}
}
