package june06_2023_post_call;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import requestbody.Request_Body;

public class Pet_ID_E2E_Testing {
    public Request_Body req_object;
    private ExtentSparkReporter spark;
    private ExtentReports extent;
    private ExtentTest logger;
    @BeforeClass
    public void setup()
    {
        req_object=new Request_Body();
        extent= new ExtentReports();
        spark=new ExtentSparkReporter(System.getProperty("user.dir")+"/TestReport/petid.html");
        extent.attachReporter(spark);
        extent.setSystemInfo("Environment","QA");
        extent.setSystemInfo("App Version","1.2");
        extent.setSystemInfo("UserName","Sandeep");
        spark.config().setDocumentTitle("Doing testing for Pet ID APIS's -- get call, Post call");
        spark.config().setTheme(Theme.DARK);
        logger =extent.createTest("Creating test report for Pet ID API's");
    }

    @Test
    public void pet_id_E2E_testing()
    {
        for(int i=200;i<300;i++)
        {
            String id=String.valueOf(i);
            String name="Animal_"+id;
            create_Pet_ID(id,name);
            validate_pet_id(id);
            delete_Pet_Id(id);

        }

    }
    public void create_Pet_ID(String pet_id,String pet_name)
    {
        //RestAssured.baseURI = "https://petstore.swagger.io/v2/pet";
        Response res =given()
                .contentType(ContentType.JSON)
                .body(req_object.creatPait_Req_Body(pet_id,pet_name))
                .when()
                .post("https://petstore.swagger.io/v2/pet");
        logger.info("Get Pet API call's for : https://petstore.swagger.io/v2/pet");
        int Pet_status_code = res.getStatusCode();
        Assert.assertEquals(Pet_status_code, 200);
        logger.pass("The Pet status code is as expected  as --> " + Pet_status_code);
        //System.out.println("the JSON code ===>" + res.asString());
        System.out.println("the status code ===>" + Pet_status_code);
        String pet_id_res=res.getBody().jsonPath().getString("id");
        String pet_name_res=res.getBody().jsonPath().getString("name");
        System.out.println("the JSON pet id===>"+pet_id_res);
        System.out.println("the JSON pet name===>"+pet_name_res);
        logger.info("the JSON pet Id : " +pet_id_res);
        logger.info("the JSON pet name : " +pet_name_res);
    }
    @Test
    public void Capital_Country_E2E_Testing()
    {
        Captial_City_Country("US");
    }
    public void Captial_City_Country(String Councd)
    {
        Response res1=given()
                .contentType(ContentType.XML)
                .body(req_object.Crete_XML_Req_body(Councd))
                .contentType("text/xml; charset=utf-8")
                .when()
                .post("http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso");
        logger.info("POST Captial Country API call's for : http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso");
        //System.out.println("The XML body of Captial Country is:  "+res1.asString());
        int Country_status_code = res1.getStatusCode();
        System.out.println("the status code ===>" + Country_status_code);
        Assert.assertEquals(Country_status_code,200);
        logger.pass("The Pet status code is as expected  as --> " + Country_status_code);
        String CapitalCity_Res=res1.getBody().xmlPath().getString("m:CapitalCityResult");
        System.out.println(CapitalCity_Res);
        logger.info("the XML Capital Country Response as  : " +CapitalCity_Res);


    }

    @Test
public void validate_pet_id(String pet_id)
{
    String runtime_pet_id="https://petstore.swagger.io/v2/pet/"+pet_id;
    Response res =given()
            .when()
            .get(runtime_pet_id);
    int get_status_code=res.getStatusCode();
    System.out.println("Get validating the Statues code ==> "+get_status_code);
    logger.info("Get validating the Statues code ==> "+get_status_code);
    Assert.assertTrue(get_status_code==200);
}
@Test
    public void delete_Pet_Id(String pet_id)
    {
        String runtime_pet_id="https://petstore.swagger.io/v2/pet/"+pet_id;
        Response res =given()
                .when()
                .get(runtime_pet_id);
        int delete_status_code=res.getStatusCode();
        System.out.println("Validating the Delete Statues code ==> "+delete_status_code);
        logger.info("Get validating the Statues code ==> "+delete_status_code);
        Assert.assertTrue(delete_status_code==200);
    }

    @AfterClass
    public void tearDump()
    {
        extent.flush();
    }
}
