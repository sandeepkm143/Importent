package package_A;

public class JavaDay1 {
int roll=10;


    public static void main (String[] args) throws Exception{
    // Create Object
        JavaDay1 obj=new JavaDay1();
        System.out.println("learning java class....");
        System.out.println(obj.roll);
    }
}
