package june19th;

import io.restassured.http.ContentType;
import org.apache.http.HttpStatus;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.hasSize;

public class BDD_Validation {
    @Test
    public void do_Authentication_Validation()
    {

        try {


            given()
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .auth().basic("user", "passwd")
                    .when()
                    .get("https://httpbin.org/basic-auth/user/passwd")
                    .then()
                    .assertThat()
                    .statusCode(HttpStatus.SC_OK)
                    .body("$", hasKey("authenticated"))
                    .body("$", hasKey("user"))
                    .body("authenticated", equalTo(true))
                    .body("user", equalTo("user"));
        }
        catch (Exception e)
        {
            System.out.println(e);
        }

    }
    @Test
    public void do_User_Validation()
    {

        try {
            given()
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .when()
                    .get("https://reqres.in/api/users?page=2")
                    .then()
                    .assertThat()
                    .statusCode(HttpStatus.SC_OK)
                    .body("$", hasKey("page"))
                    .body("$", hasKey("total_pages"))
                    .body("page", equalTo(2))
                    .body("data[1].email", equalTo("lindsay.ferguson@reqres.in"))
                    .body("data.id", hasSize(6))
                    .body("total_pages", equalTo(2));

        }
        catch (Exception e)
        {
            System.out.println(e);
        }

    }
}
