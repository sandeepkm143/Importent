package may19;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Test_004 {
   // @Test
    @Parameters({"Name","Pwd"})
    public static void GoogleLogin(String Name, String Pwd)
    {
        System.out.println("Enter User ID ===>"+Name);
        System.out.printf("Enter User Password ===>"+Pwd);

    }

    //@Test
    @Parameters({"StatusCode"})
    public void Validate_Get_Call(String StatusCode)

    {

        String Runtime_Status_Code="200";
        Assert.assertEquals(Runtime_Status_Code,StatusCode);
        Assert.assertTrue(Runtime_Status_Code.equals(StatusCode));
        Assert.assertTrue(Integer.parseInt(Runtime_Status_Code)==Integer.parseInt(StatusCode));

    }

    @Test
    public void Facebook_Testing()
    {
        System.out.println("We are doing facebook testing");
    }

}
