package jdbc_june21;

import org.testng.annotations.Test;
import java.sql.*;

public class Jdbc_TC001 {

    @Test
    public void Play_Database() {
        try {
            //crete_Database();
            //crete_Table();
            //insert_Table_Details();
            //delete_Database();
            read_Title(9);
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    public void crete_Database() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306", "root", "admin");
            Statement smt_obj = con.createStatement();
            smt_obj.execute("create database API_INFO;");
            System.out.println("Database is Created");
            smt_obj.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void crete_Table() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306/API_INFO", "root", "admin");
            Statement smt_obj = con.createStatement();
            //smt_obj.execute("use Student_info");
            String query = "create Table Test_DATA(" +
                    "S_NO int(20)," +
                    "URL varchar(255)," +
                    "Title varchar(255)," +
                    "Status_Code int(20));";
            smt_obj.executeUpdate(query);
            System.out.println("Table is Created");
            smt_obj.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void insert_Table_Details() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306/API_INFO", "root", "admin");
            Statement smt_obj = con.createStatement();
            //smt_obj.execute("use Student_info");
            String query = "INSERT INTO Test_DATA (S_NO,URL,Title,Status_Code) " +
                    "VALUES(01,'https://www.google.com','Google',200)," +
                    "(02,'https://www.w3schools.com','W3Schools Online Web Tutorials',200)," +
                    "(03,'https://rest-assured.io','REST Assured',200)," +
                    "(04,'https://classroom.edyoda.com','EdYoda Digital University',200)," +
                    "(05,'https://testng.org','TestNG - Welcome',200)," +
                    "(06,'https://www.selenium.dev','Selenium',200)" +
                    ",(07,'https://www.guru99.com/','Meet Guru99 – Free Training Tutorials & Video for IT Courses',200)," +
                    "(08,'https://www.javatpoint.com/','Tutorials List - Javatpoint',200)," +
                    "(09,'https://www.restapitutorial.com/','REST API Tutorial',200)";
            smt_obj.executeUpdate(query);
            System.out.println("Multiple row Inseted");
            smt_obj.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void delete_Database() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306", "root", "admin");
            Statement smt_obj = con.createStatement();
            smt_obj.execute("DROP DATABASE delete_database");
            System.out.println("Data base deleted sucsussfully");
            smt_obj.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public void read_Title(int Sno) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306/API_INFO", "root", "admin");
            Statement smt_obj = con.createStatement();
            ResultSet result = smt_obj.executeQuery("select S_NO,URL,Title,Status_code from test_data;");
            while (result.next()) {
                int sln = result.getInt(1);
                if (sln == Sno) {
                    String title = result.getString(3);
                    System.out.println(title);
                }

            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }


    }


}
