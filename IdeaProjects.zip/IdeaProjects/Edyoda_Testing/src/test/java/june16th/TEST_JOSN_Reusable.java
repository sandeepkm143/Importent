package june16th;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import requestbody.Request_Body;
import reusable.Reusable_Fun;

import static io.restassured.RestAssured.given;

public class TEST_JOSN_Reusable {

    Reusable_Fun obj;
    Request_Body req_object;
    String tcname=null;
    String testcasename=null;
    @BeforeClass
    public void setup()
    {
        obj=new Reusable_Fun();
        req_object=new Request_Body();
    }
    @Test
    public void do_google_get_call_validation()
    {
        tcname="TC_001";
        try {
            RestAssured.baseURI = "https://"+obj.Read_JOSN_file(tcname,"URL");
            //logger.info("Get API call's for : https://www.google.com ");
            Response google_res = RestAssured.get();
            int google_status_code = google_res.getStatusCode();
            System.out.println("the status code ===>" + google_status_code);
            Assert.assertEquals(google_status_code,Integer.parseInt(obj.Read_JOSN_file(tcname,"StatusCode")));
            //logger.pass("The status code is as expected  as --> " + google_status_code);
            String google_response_text = google_res.asString();
            System.out.println("The Response text is ==>" + google_response_text);
            Assert.assertTrue(google_response_text.contains(obj.Read_JOSN_file(tcname,"Title")));
            //logger.pass("The response string is as expected  as 'Google'");
        }
        catch (Exception e)
        {
            System.out.println(e);
            //logger.fail(e);
            //logger.fail("API get call validation for google not working");
        }
    }
@Test
    public void create_Pet_ID()
    {
        tcname="TC_005";
        testcasename="TC_006";
        try {
            //RestAssured.baseURI = "https://petstore.swagger.io/v2/pet";
            System.out.println(obj.read_Properties_File("petstore_url"));
            Response res = given()
                    .contentType(ContentType.JSON)
                    .body(req_object.creatPait_Req_Body(obj.read_Excel(testcasename,"pet_Id"),obj.read_Excel(testcasename,"pet_name")))
                    .when()
                    .post(obj.read_Properties_File("petstore_url"));
            System.out.printf(res.asString());
            int Pet_status_code = res.getStatusCode();
            Assert.assertEquals(Pet_status_code, Integer.parseInt(obj.Read_JOSN_file(tcname,"StatusCode")));
            //System.out.println("the JSON code ===>" + res.asString());
            System.out.println("the status code ===>" + Pet_status_code);
            String pet_id_res = res.getBody().jsonPath().getString("id");
            String pet_name_res = res.getBody().jsonPath().getString("name");
            System.out.println("the JSON pet id===>" + pet_id_res);
            System.out.println("the JSON pet name===>" + pet_name_res);
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    @Test
    public void do_w3school_get_call_validation()
    {
        tcname="TC_002";
        try {
            RestAssured.baseURI = "https://"+obj.Read_JOSN_file(tcname,"URL");;
            Response w3school_res = RestAssured.get();
            int w3school_status_code = w3school_res.getStatusCode();
            System.out.println("the status code ===>" + w3school_status_code);
            Assert.assertEquals(w3school_status_code, Integer.parseInt(obj.Read_JOSN_file(tcname,"StatusCode")));
            String W3school_res_txt = w3school_res.asString();
            System.out.println("The Response text is ==>" + W3school_res_txt);
            Assert.assertTrue(W3school_res_txt.contains(obj.Read_JOSN_file(tcname,"Title")));
        }
        catch (Exception e)
        {
            System.out.println(e);
        }

    }
    }

