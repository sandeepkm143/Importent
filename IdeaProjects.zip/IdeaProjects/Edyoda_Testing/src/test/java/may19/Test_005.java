package may19;
import org.testng.annotations.BeforeClass;
import reusable.Reusable_Fun;

import org.testng.annotations.Test;

public class Test_005 {

    private Reusable_Fun re_obj;

    @BeforeClass
    public void do_Initial_Steps()
    {
        re_obj=new Reusable_Fun();

    }

    @Test(groups ={"E2E","Smoke","P1"})
    public void Test_API_001()
    {
        //re_obj=new Reusable();
        System.out.println("Executing Test_API_001");
        System.out.println("The URL is ===>"+re_obj.read_Properties_File("url"));
    }
    @Test(groups ={"Regression"})
    public void Test_API_002()
    {
        System.out.println("Executing Test_API_002");
    }
    @Test(groups ={"Smoke"})
    public void Test_API_003()
    {
        System.out.println("Executing Test_API_003");
        System.out.println("The Email is ===>"+re_obj.read_Properties_File("email"));
    }
    @Test(groups ={"E2E"})
    public void Test_API_004()
    {
        System.out.println("Executing Test_API_004");
    }
    @Test(groups ={"Regression"})
    public void Test_API_005()
    {
        System.out.println("Executing Test_API_005");
    }
    @Test(groups ={"Smoke"})
    public void Test_API_006()
    {
        System.out.println("Executing Test_API_006");
        System.out.println("The Phone number is ===>"+re_obj.read_Properties_File("mobnum"));
    }
    @Test(groups ={"Smoke"})
    public void Test_API_007()
    {
        System.out.println("Executing Test_API_007");
    }
    @Test(groups ={"Regression"})
    public void Test_API_008()
    {
        System.out.println("Executing Test_API_008");
    }
    @Test(groups ={"E2E"})
    public void Test_API_009()
    {
        System.out.println("Executing Test_API_009");
    }
    @Test(groups ={"E2E"},priority=1)
    public void Test_API_010()
    {
        System.out.println("Executing Test_API_010");
    }






}
