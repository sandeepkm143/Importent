package june13th;

import io.restassured.path.xml.XmlPath;
import io.restassured.path.xml.config.XmlPathConfig;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import requestbody.Request_Body;
import reusable.Reusable_Fun;

import static io.restassured.RestAssured.*;
import static io.restassured.path.xml.config.XmlPathConfig.xmlPathConfig;


public class SOAP_Get_Call {
    public Request_Body obj;
    public Reusable_Fun excel_obj;
    public String testcase_id=null;
    public String tcname=null;

    @BeforeClass
    public void setup()
    {
        obj=new Request_Body();
        excel_obj=new Reusable_Fun();
    }


    @Test
    public void Get_Call_Book_Store()
    {
        Response res=given()
                .relaxedHTTPSValidation()
                .when()
                .get("https://chercher.tech/sample/api/books.xml");
        //System.out.println(res.getBody().asString());
        XmlPath xml_obj=new XmlPath(res.getBody().asString()).using(xmlPathConfig().namespaceAware(false));
        int book_count=xml_obj.get("bookstore.book.size()");
        System.out.println("Total book count is ---> " +book_count);

        String book_name=xml_obj.getString("bookstore.book[0].title");
        System.out.println("The first book title is ---->" +book_name);
        String book_category=xml_obj.getString("bookstore.book[1].@category");
        System.out.println("The Secount book category is ---->" +book_category);
        String book_lang=xml_obj.getString("bookstore.book[0].title.@lang");
        System.out.println("The first book lange is ---->" +book_lang);
    }
    @Test
    public void Post_Call_Validation()throws Exception
    {
        testcase_id="TC_005";
        Response res=excel_obj.SOAP_XML_Response_Body("https://www.w3schools.com/xml/tempconvert.asmx",
                obj.Fahrenheit(excel_obj.read_Excel(testcase_id,"Celsiusvalue")),
                obj.Crete_XML_Req_body(excel_obj.read_Properties_File("header")));
            System.out.println(res.getBody().asString());
            XmlPath xml_obj = new XmlPath(res.getBody().asString()).using(xmlPathConfig().namespaceAware(false));

            String Fahrenheit_Res = xml_obj.getString("soap:Envelope.soap:Body.CelsiusToFahrenheitResponse.CelsiusToFahrenheitResult");
            System.out.println("####"+Fahrenheit_Res);
            String excel_data=excel_obj.read_Excel(testcase_id,"FahrenheitValue");
        System.out.printf("******"+excel_data);
        if(excel_data.contains(".0")||excel_data.contains(".00"))
        {
            int Fahren_Res=Integer.parseInt(Fahrenheit_Res);
            Assert.assertEquals(Fahren_Res,Integer.parseInt(excel_data));
        }
        else
        {
            Assert.assertEquals(Fahrenheit_Res,excel_data);
        }

        }

    }

