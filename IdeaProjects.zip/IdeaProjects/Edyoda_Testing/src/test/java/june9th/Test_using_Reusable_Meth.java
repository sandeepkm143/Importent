package june9th;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import reusable.Reusable_Fun;

public class Test_using_Reusable_Meth {

    public Reusable_Fun obj;
    public String testcase_id=null;

    @BeforeClass
    public void setup()
    {
        obj=new Reusable_Fun();

    }


    @Test
    public void do_google_get_call_validation()
    {
        testcase_id="TC_001";
        try {
            RestAssured.baseURI = obj.read_Excel(testcase_id,"URL");
            //logger.info("Get API call's for : https://www.google.com ");
            Response google_res = RestAssured.get();
            int google_status_code = google_res.getStatusCode();
            System.out.println("the status code ===>" + google_status_code);
            Assert.assertEquals(google_status_code, 200);
            //logger.pass("The status code is as expected  as --> " + google_status_code);
            String google_response_text = google_res.asString();
            System.out.println("The Response text is ==>" + google_response_text);
            Assert.assertTrue(google_response_text.contains(obj.read_Excel(testcase_id,"Title")));
            //logger.pass("The response string is as expected  as 'Google'");
        }
        catch (Exception e)
        {
            //logger.fail(e);
            //logger.fail("API get call validation for google not working");y
            System.out.println(e);
        }
    }
    @Test
    public void do_w3school_get_call_validation()
    {
        testcase_id="TC_002";
        RestAssured.baseURI=obj.read_Excel(testcase_id,"URL");;
        //logger.info("Get API call's for : https://www.w3schools.com/ ");
        Response w3school_res=RestAssured.get();
        int w3school_status_code=w3school_res.getStatusCode();
        System.out.println("the status code ===>" +w3school_status_code);
        Assert.assertEquals(w3school_status_code,200);
        //logger.pass("The status code is as expected  as --> " + w3school_status_code);
        String W3school_res_txt=w3school_res.asString();
        System.out.println("The Response text is ==>"+W3school_res_txt);
        Assert.assertTrue(W3school_res_txt.contains(obj.read_Excel(testcase_id,"Title")));
        //logger.pass("The title expected  as 'W3Schools Online Web Tutorials'");
    }

    //https://rest-assured.io/
    @Test
    public void do_rest_assured_get_call_validation()
    {
        testcase_id="TC_003";
        RestAssured.baseURI=obj.read_Excel(testcase_id,"URL");
        //logger.info("Get API calls for : https://rest-assured.io/");
        Response rest_assured_res=RestAssured.get();
        int rest_assured_status_code=rest_assured_res.getStatusCode();
        System.out.println("the status code ===>" +rest_assured_status_code);
        Assert.assertEquals(rest_assured_status_code,200);
        //logger.pass("The status code is as expected  as --> " + rest_assured_status_code);
        String rest_assured_res_txt=rest_assured_res.asString();
        System.out.println("The Response text is ==>"+rest_assured_res_txt);
        Assert.assertTrue(rest_assured_res_txt.contains(obj.read_Excel(testcase_id,"Title")));
    }

    //https://www.onlinegdb.com/
    @Test

    public void do_java_cmp_get_call_validation()
    {
        testcase_id="TC_003";
        RestAssured.baseURI=obj.read_Excel(testcase_id,"URL");
        //logger.info("Get API calls for: https://www.onlinegdb.com/ ");
        Response java_cmp_res=RestAssured.get();
        int java_cmp_status_code=java_cmp_res.getStatusCode();
        System.out.println("the status code ===>" +java_cmp_status_code);
        Assert.assertEquals(java_cmp_status_code,200);
        //logger.pass("The status code is as expected  as --> " + java_cmp_status_code);
        String java_cmp_res_txt=java_cmp_res.asString();
        System.out.println("The Response text is ==>"+java_cmp_res_txt);
        Assert.assertTrue(java_cmp_res_txt.contains(obj.read_Excel(testcase_id,"Title")));
    }
}
