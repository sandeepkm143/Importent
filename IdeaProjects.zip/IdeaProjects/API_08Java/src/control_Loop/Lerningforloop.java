package control_Loop;

public class Lerningforloop {
    public static void main(String[] args)throws Exception{
        Lerningforloop obj=new Lerningforloop();
        //obj.runforloop1_to_100(20);
        obj.lernWhileLoop();
    }

    // Ths if for : For Loop

    public void runforloop1_to_100(int x)
    {
        for (int i=1;i<=x;i++)
        {

            System.out.println("the current number is: ==>" +i);
        }
    }

    // This is for while loop

    public void lernWhileLoop()
    {
        int i=1,a=50;

        while (i>a)
        {
            System.out.println("the current number is while loop ==>" +i);
            i++;
        }

    }
}
