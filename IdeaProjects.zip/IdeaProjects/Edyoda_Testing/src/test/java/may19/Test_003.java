package may19;

import org.testng.annotations.Test;

public class Test_003 {

    @Test(priority = 1)
    public void testing_age_Page()
    {
        System.out.println("3/0");
    }
    @Test(priority = 2)
    public void testing_amezon_Page()
    {
        System.out.println("I am executing my first amezon script");
    }
}
