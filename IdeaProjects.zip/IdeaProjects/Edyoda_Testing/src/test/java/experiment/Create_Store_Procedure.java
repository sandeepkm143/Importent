package experiment;

import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Create_Store_Procedure {

    @Test
    public void read_Data()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306/API_INFO", "root", "admin");
            Statement smt_obj = con.createStatement();
            ResultSet result = smt_obj.executeQuery("call Reade_Table_API");
            while (result.next()) {
                int sln = result.getInt(1);
                String url = result.getString(2);
                String title = result.getString(3);
                int status = result.getInt(4);
                System.out.println("The Seriole number   :" + sln);
                System.out.println("The url is   :" + url);
                System.out.println("The title is  :" + title);
                System.out.println("The status code is   :" + status);
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Test
    public void crate_Procedure()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306", "root", "admin");
            Statement smt_obj = con.createStatement();
            smt_obj.execute("use API_INFO");
            String query="DELIMITER  //" +
                    "CREATE PROCEDURE Read_API_URL1 ()" +
                    "BEGIN" +
                    "SELECT * FROM test_data;" +
                    "END //" +
                    "" +
                    "DELIMITER ;";
           smt_obj.execute(query);
            System.out.println("Stored Procedure Crated");
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}
