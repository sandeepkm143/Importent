package may19;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Test_002 {

    @BeforeClass
    public void dosetupforTC002()
    {
        System.out.println("Start API server for Tc002");
    }
    @Test(priority = 1)
    public void testing_Firefox_Page()
    {
        System.out.println("I am executing my first Fire fox script");
    }
    @Test(priority = 2)
    public void testing_Edge_Page()
    {
        System.out.println(200+500);
    }

    @AfterClass
    public void closesetupforTC001()
    {
        System.out.println("stop API server for Tc002");
    }

}
