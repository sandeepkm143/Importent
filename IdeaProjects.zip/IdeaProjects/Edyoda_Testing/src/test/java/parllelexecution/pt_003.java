package parllelexecution;

import org.testng.annotations.Test;

public class pt_003 {
    @Test
    public void Twitter_pt_001_01()
    {
        System.out.println("Twitter_pt_001_01");
    }
    @Test
    public void Twitter_pt_001_02()
    {
        System.out.println("Twitter_pt_001_02");
    }
    @Test
    public void Twitter_pt_001_03()
    {
        System.out.println("Twitter_pt_001_03");
    }
    @Test
    public void Twitter_pt_001_04()
    {
        System.out.println("Twitter_pt_001_04");
    }
    @Test
    public void Twitter_pt_001_05()
    {
        System.out.println("Twitter_pt_001_05");
    }
    @Test
    public void Twitter_pt_001_06()
    {
        System.out.println("Twitter_pt_001_06");
    }
    @Test
    public void Twitter_pt_001_07()
    {
        System.out.println("Twitter_pt_001_07");
    }
    @Test
    public void Twitter_pt_001_08()
    {
        System.out.println("Twitter_pt_001_08");
    }
    @Test
    public void Twitter_pt_001_09()
    {
        System.out.println("Twitter_pt_001_09");
    }
    @Test
    public void Twitter_pt_001_10()
    {
        System.out.println("Twitter_pt_001_10");
    }
}
