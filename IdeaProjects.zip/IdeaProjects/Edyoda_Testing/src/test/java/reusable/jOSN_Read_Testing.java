package reusable;

import org.testng.annotations.Test;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.io.FileReader;
import java.util.Iterator;
import java.util.Map;


public class jOSN_Read_Testing
{
    public Object file_obj;
    public JSONArray JA;
    public JSONObject JO;

    public static void main(String[] args) throws Exception
    {
        jOSN_Read_Testing obj=new jOSN_Read_Testing();
        obj.Read_JOSN_file();
    }


    public void Read_JOSN_file()throws Exception
    {
       file_obj=new JSONParser()
               .parse(new FileReader("C:\\Users\\sandeepkm\\IdeaProjects\\Edyoda_Testing\\API_Test_Data.json"));
       JO=(JSONObject)file_obj;
       JA=(JSONArray)JO.get("Automation_API");
        Iterator ITR=JA.iterator();
        while (ITR.hasNext())
        {
            Iterator < Map.Entry> ITR_child=((Map)ITR.next()).entrySet().iterator();
            while (ITR_child.hasNext())
            {
                Map.Entry pair = ITR_child.next();
                //System.out.println(pair.getKey());
                //System.out.println(pair.getValue());
                if(pair.getKey().toString().equals("TC_002"))
                {
                    System.out.println(pair.getValue());
                    String[] child_element=pair.getValue().toString().split(",");
                    for(int i=0;i<child_element.length;i++)
                    {
                        String x=child_element[i];
                        String key_data = child_element[i].split(":")[0]
                                .replaceAll("[*{}\"]","");
                        String value_data = child_element[i].split(":")[1]
                                .replaceAll("[*{}\"]","");
                        System.out.println(key_data);
                        System.out.println(value_data);
                        if (key_data.equals("URL"))
                        {
                            System.out.println(value_data);
                        }
                    }
                }
            }
        }
    }
}
