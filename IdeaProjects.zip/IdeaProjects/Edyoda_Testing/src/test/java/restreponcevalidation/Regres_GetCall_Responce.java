package restreponcevalidation;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import reusable.Reusable_Fun;

import static io.restassured.RestAssured.given;

public class Regres_GetCall_Responce {

    Reusable_Fun res_obj;
    @BeforeClass
    public void setup()
    {
        res_obj=new Reusable_Fun();
    }

    @Test
    public void regress_GetCall_Validation()
    {

        Response res =given()
                .when()
                .get("https://reqres.in/api/users?page=2");
        int get_status_code=res.getStatusCode();
        System.out.println("The status code is "+get_status_code);
        System.out.println(res.asString());
        String get_call_responcei_text=res.getBody().jsonPath().getString("support.text");
        System.out.println("Body Text is : " +get_call_responcei_text);
        System.out.println(res_obj.read_Properties_File("support_text"));
        Assert.assertEquals(res_obj.read_Properties_File("support_text"),get_call_responcei_text);
    }
        @Test
    public void autorization_Validation()
    {
        String URI="https://httpbin.org/basic-auth/user/passwd";
        Response res1=given()
                .auth()
                .basic("user","passwd")
                .when()
                .get(URI);
        int get_aut_status_code=res1.getStatusCode();
        System.out.println("The status code is "+get_aut_status_code);
        System.out.println(res1.asString());
        String aut_txt=res1.getBody().jsonPath().getString("authenticated");
        System.out.println(aut_txt);
        Assert.assertEquals(aut_txt,res_obj.read_Properties_File("text"));


    }
}
