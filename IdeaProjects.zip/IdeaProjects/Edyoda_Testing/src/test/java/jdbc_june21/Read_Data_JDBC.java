package jdbc_june21;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.sql.*;


public class Read_Data_JDBC {
    private ExtentSparkReporter spark;
    private ExtentReports extent;
    private ExtentTest logger;
    //Reusable res_obj;

    @BeforeClass
    public void setup() {

        //res_obj=new Reusable();
        // Create an object of ExtentReports
        extent = new ExtentReports();
        spark = new ExtentSparkReporter(System.getProperty("user.dir") + "/TestReport/API.html");
        extent.attachReporter(spark);
        extent.setSystemInfo("Environment", "QA");
        extent.setSystemInfo("App Version", "1.2");
        extent.setSystemInfo("UserName", "Sandeep");
        spark.config().setDocumentTitle("Doing testing for Sample APIS's -- get call");
        spark.config().setTheme(Theme.DARK);
        logger = extent.createTest("Creating test report for google API's");
    }

    @Test
    public void read_data() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306/API_INFO", "root", "admin");
            Statement smt_obj = con.createStatement();
            ResultSet result = smt_obj.executeQuery("select S_NO,URL,Title,Status_code from test_data;");
            while (result.next()) {
                int sln = result.getInt(1);
                String url = result.getString(2);
                String title = result.getString(3);
                int status = result.getInt(4);
                System.out.println("The Seriole number   :" + sln);
                System.out.println("The url is   :" + url);
                System.out.println("The title is  :" + title);
                System.out.println("The status code is   :" + status);
                do_Get_API_Call(url, title, status);

            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void do_Get_API_Call(String URL, String title, int status) {
        try {
            RestAssured.baseURI = URL;
            logger.info("Get API call's for : " + URL);
            Response google_res = RestAssured.get();
            int google_status_code = google_res.getStatusCode();
            System.out.println("the status code ===>" + google_status_code);
            Assert.assertEquals(google_status_code, status);
            logger.pass("The status code is as expected  as --> " + google_status_code);
            String google_response_text = google_res.asString();
            //System.out.println("The Response text is ==>" + google_response_text);
            Assert.assertTrue(google_response_text.contains(title));
            logger.pass("The response string is as expected  as :" + title);
        } catch (Exception e) {
            logger.fail(e);
            logger.fail("API get call validation for google not working");
            //System.out.println(e);
        }
    }
        @AfterClass
        public void tearDump ()
        {
            extent.flush();
        }
    }
