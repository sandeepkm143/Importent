package jun01_rest_assured_day1;
import com.aventstack.extentreports.reporter.configuration.Theme;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.*;

public class Test_Google {

    // To generate automated test reports

    private ExtentSparkReporter spark;
    private ExtentReports extent;
    private ExtentTest logger;
    //Reusable res_obj;
    @BeforeClass
    public void setup()
    {

        //res_obj=new Reusable();
        // Create an object of ExtentReports
        extent= new ExtentReports();
        spark=new ExtentSparkReporter(System.getProperty("user.dir")+"/TestReport/google.html");
        extent.attachReporter(spark);
        extent.setSystemInfo("Environment","QA");
        extent.setSystemInfo("App Version","1.2");
        extent.setSystemInfo("UserName","Sandeep");
        spark.config().setDocumentTitle("Doing testing for Google APIS's -- get call, Post call");
        spark.config().setTheme(Theme.DARK);
        logger =extent.createTest("Creating test report for google API's");
    }
    // Validate the google Get call
    @Test
    public void do_google_get_call_validation()
    {
        try {
            RestAssured.baseURI = "https://www.google.com";
            logger.info("Get API call's for : https://www.google.com ");
            Response google_res = RestAssured.get();
            int google_status_code = google_res.getStatusCode();
            System.out.println("the status code ===>" + google_status_code);
            Assert.assertEquals(google_status_code, 200);
            logger.pass("The status code is as expected  as --> " + google_status_code);
            String google_response_text = google_res.asString();
            System.out.println("The Response text is ==>" + google_response_text);
            Assert.assertTrue(google_response_text.contains("<title>Google</title>"));
            logger.pass("The response string is as expected  as 'Google'");
        }
        catch (Exception e)
        {
            logger.fail(e);
            logger.fail("API get call validation for google not working");
        }
    }
    // Validate the w3school Get call
    @Test
    public void do_w3school_get_call_validation()
    {
        RestAssured.baseURI="https://www.w3schools.com/";
        logger.info("Get API call's for : https://www.w3schools.com/ ");
        Response w3school_res=RestAssured.get();
        int w3school_status_code=w3school_res.getStatusCode();
        System.out.println("the status code ===>" +w3school_status_code);
        Assert.assertEquals(w3school_status_code,200);
        logger.pass("The status code is as expected  as --> " + w3school_status_code);
        String W3school_res_txt=w3school_res.asString();
        System.out.println("The Response text is ==>"+W3school_res_txt);
        Assert.assertTrue(W3school_res_txt.contains("<title>W3Schools Online Web Tutorials</title>"));
        logger.pass("The title expected  as 'W3Schools Online Web Tutorials'");
    }
    //https://classroom.edyoda.com/
    @Test
    public void do_edyoda_get_call_validation()
    {
        RestAssured.baseURI="https://classroom.edyoda.com/";
        logger.info("Get API calls for : https://classroom.edyoda.com/");
        Response edyoda_res=RestAssured.get();
        int edyoda_status_code=edyoda_res.getStatusCode();
        System.out.println("the status code ===>" +edyoda_status_code);
        Assert.assertEquals(edyoda_status_code,200);
        logger.pass("The status code is as expected  as --> " + edyoda_status_code);
        String edyoda_res_txt=edyoda_res.asString();
        System.out.println("The Response text is ==>"+edyoda_res_txt);
    }

    //https://rest-assured.io/
    @Test
    public void do_rest_assured_get_call_validation()
    {
        RestAssured.baseURI="https://rest-assured.io/";
        logger.info("Get API calls for : https://rest-assured.io/");
        Response rest_assured_res=RestAssured.get();
        int rest_assured_status_code=rest_assured_res.getStatusCode();
        System.out.println("the status code ===>" +rest_assured_status_code);
        Assert.assertEquals(rest_assured_status_code,200);
        logger.pass("The status code is as expected  as --> " + rest_assured_status_code);
        String rest_assured_res_txt=rest_assured_res.asString();
        System.out.println("The Response text is ==>"+rest_assured_res_txt);
    }

    //https://www.onlinegdb.com/
    @Test
    public void do_java_cmp_get_call_validation()
    {
        RestAssured.baseURI="https://www.onlinegdb.com/";
        logger.info("Get API calls for: https://www.onlinegdb.com/ ");
        Response java_cmp_res=RestAssured.get();
        int java_cmp_status_code=java_cmp_res.getStatusCode();
        System.out.println("the status code ===>" +java_cmp_status_code);
        Assert.assertEquals(java_cmp_status_code,200);
        logger.pass("The status code is as expected  as --> " + java_cmp_status_code);
        String java_cmp_res_txt=java_cmp_res.asString();
        System.out.println("The Response text is ==>"+java_cmp_res_txt);
    }
    @AfterClass
    public void tearDump()
    {
        extent.flush();
    }
}
