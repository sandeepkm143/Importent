package may19;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class Support {


    @BeforeSuite
    public void do_Setup_Before_Execution()
    {
        System.out.println("do data base connection");
    }
    @AfterSuite
    public void do_Desconnect_After_Execution()
    {
        System.out.println("do data base disconnection after execution");
    }




}
