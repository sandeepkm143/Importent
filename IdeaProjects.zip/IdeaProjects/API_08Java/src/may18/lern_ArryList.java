package may18;

import java.util.ArrayList;

public class lern_ArryList {

    public static void main(String args[])
    {
        lern_ArryList obj=new lern_ArryList();
        obj.learn_Arraylist();
    }

    public void learn_Arraylist()
    {
        // Data adding to array list
        ArrayList<Integer> Empid=new ArrayList<Integer>();
        Empid.add(123);
        Empid.add(124);
        Empid.add(125);
        Empid.add(126);
        Empid.add(127);
        System.out.println("Print emp id===>"+Empid.get(3));
        Empid.add(301);
        Empid.add(555);
        System.out.println("Print emp id===>"+Empid.get(5));

        // Remove data from arry list
        System.out.println("Print emp id of position '0'===>"+Empid.get(0));
        Empid.remove(0);
        System.out.println("Print emp id of position '0'===>"+Empid.get(0));

        // Replacing/Reseting data
        System.out.println("Print emp id of position '3'===>"+Empid.get(3));
        Empid.set(3,521);
        System.out.println("Print emp id of position '3'===>"+Empid.get(3));
        // Print arrylist one by one

        System.out.println("***********************");
        for(int a:Empid)
        {
            System.out.println("Print Empid"+a);
        }

        System.out.println("***********##########");
        for (int i=0;i<Empid.size();i++)
        {
            System.out.println(Empid.get(i));
        }
    }
}
