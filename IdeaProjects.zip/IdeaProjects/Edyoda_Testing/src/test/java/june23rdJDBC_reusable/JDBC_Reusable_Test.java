package june23rdJDBC_reusable;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;
import reusable.Reusable_Fun;

public class JDBC_Reusable_Test {
    Reusable_Fun obj;
    @Test
    public void read_Data_SQL_query()
    {
        obj=new Reusable_Fun();
        RestAssured.baseURI = obj.read_Title_Query(Integer.valueOf(obj.read_Properties_File("s_no")));
       // logger.info("Get API call's for : https://www.google.com ");
        Response google_res = RestAssured.get();
        int google_status_code = google_res.getStatusCode();
        System.out.println("the status code ===>" + google_status_code);
        Assert.assertEquals(google_status_code, 200);
        //logger.pass("The status code is as expected  as --> " + google_status_code);
        String google_response_text = google_res.asString();
        System.out.println("The Response text is ==>" + google_response_text);
        Assert.assertTrue(google_response_text.contains("<title>Google</title>"));
        //logger.pass("The response string is as expected  as 'Google'");
    }
}
