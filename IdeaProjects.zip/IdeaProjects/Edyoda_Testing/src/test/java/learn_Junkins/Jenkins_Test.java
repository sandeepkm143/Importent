package learn_Junkins;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Jenkins_Test {
    @Test
    public void do_google_get_call_validation() {
        try {
            RestAssured.baseURI = "https://www.google.com";
            //logger.info("Get API call's for : https://www.google.com ");
            Response google_res = RestAssured.get();
            int google_status_code = google_res.getStatusCode();
            System.out.println("the status code ===>" + google_status_code);
            Assert.assertEquals(google_status_code, 200);
            //logger.pass("The status code is as expected  as --> " + google_status_code);
            String google_response_text = google_res.asString();
            System.out.println("The Response text is ==>" + google_response_text);
            Assert.assertTrue(google_response_text.contains("<title>Google</title>"));
            //logger.pass("The response string is as expected  as 'Google'");
        } catch (Exception e) {
            //logger.fail(e);
            //logger.fail("API get call validation for google not working");
        }


    }
}
