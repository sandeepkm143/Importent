package experiment;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

import java.io.FileInputStream;

public class ReadExcel2 {
    @Test
    public void readData()
    {

String header="Content-Type,application/soap+xml; charset=utf-8";
        System.out.println(header.split(",")[0]);
        System.out.println(header.split(",")[1]);
    }

}
