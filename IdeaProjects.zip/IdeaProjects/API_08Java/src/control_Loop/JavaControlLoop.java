package control_Loop;

public class JavaControlLoop {
    public static void main(String[] args)throws Exception{

        JavaControlLoop obj=new JavaControlLoop();
        obj.grade_the_marks(20);
    }


    public void grade_the_marks(int marks)
    {
        if(marks<30){
            System.out.println("Fail");
        }

        if(marks>30) {
            System.out.println("Pass");
        }
    }
}
