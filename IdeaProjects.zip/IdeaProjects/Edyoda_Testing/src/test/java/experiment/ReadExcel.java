package experiment;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.testng.annotations.Test;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;

public class ReadExcel {

    @Test
    public void read_Test_Data_From_Excel()
    {
        try{
            String excel_path="C:\\Users\\sandeepkm\\IdeaProjects\\Edyoda_Testing\\TestData\\Automatio_test_Data1.xlsx";
            //Read the Excel path
            FileInputStream fls=new FileInputStream(excel_path);
            // Get the Workbook access
            Workbook workbook=new XSSFWorkbook(fls);
            // Read data from specific sheet
            Sheet sheet=workbook.getSheet("Sheet1");
            int RC_count=sheet.getLastRowNum();
            System.out.println("Get the row number  " +RC_count);
            for (int i=0;i<=RC_count;i++)
            {
                Row row=sheet.getRow(0);
                int Col_count=row.getLastCellNum();
               // System.out.println("Total column count of row number:" +Col_count);
                for(int j=1;j<Col_count;j++)
                {
                    Cell cell=row.getCell(j);
                    String tex_value=cell.getStringCellValue();
                    System.out.println("The cell value is "+tex_value);
                }
            }
        }
        catch (Exception e)
        {

        }
    }
    @Test
    public void read_Test_Data_From_Excel_aspertestcasess(String testcasename,String param,String param1)
    {
        try{
            String excel_path="C:\\Users\\sandeepkm\\IdeaProjects\\Edyoda_Testing\\TestData\\Automatio_test_Data.xlsx";
            //Read the Excel path
            FileInputStream fls=new FileInputStream(excel_path);
            // Get the Workbook access
            Workbook workbook=new XSSFWorkbook(fls);
            // Read data from specific sheet
            Sheet sheet=workbook.getSheet("Sheet1");
            int RC_count=sheet.getLastRowNum();
            System.out.println("Get the row number  " +RC_count);
            for (int i=0;i<=RC_count;i++)
            {
                Row row=sheet.getRow(i);
                int Col_count=row.getLastCellNum();
                // System.out.println("Total column count of row number:" +Col_count);
                Cell cell=row.getCell(0);
                String value=cell.getStringCellValue();
                //System.out.println("the columan value is --->" +value);
                //System.out.println("******************");
                if(value.equals(testcasename))
                {
                    System.out.println("The row number is :"+i);
                    Row newrow=sheet.getRow(0);

                    for(int j=0;j<Col_count;j++)
                    {
                        Cell cellnum=newrow.getCell(j);
                        String valueofcell=cellnum.getStringCellValue();
                        if(valueofcell.equals(param))
                        {
                            System.out.println("The URL is"+sheet.getRow(i).getCell(j));
                        }
                        else if(valueofcell.equals(param1))
                        {
                            System.out.println("The title is :  "+sheet.getRow(i).getCell(j));
                        }

                    }
                }
            }
        }
        catch (Exception e)
        {

        }
    }
}
